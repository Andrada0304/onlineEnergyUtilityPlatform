export const HOST = {
    backend_api: 'http://localhost:8080',
};
