package ro.tuc.ds2020.entities;

public enum Roles {
    ADMINISTRATOR,
    CLIENT
}

