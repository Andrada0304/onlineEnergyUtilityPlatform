INSERT INTO person (id, name, address, age) values
    ('00201D1E61F3401588BF4292B86E22E4', 'My Name', 'My Address', 20);
